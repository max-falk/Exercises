#This is a better script
# Done using a new approach
#This script isnt going to work
